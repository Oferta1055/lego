// Funções de interface básica
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar && overlay) {
        sidebar.classList.toggle('open');
        if (sidebar.classList.contains('open')) {
            overlay.style.display = 'block';
            setTimeout(() => overlay.classList.add('open'), 10);
            document.body.style.overflow = 'hidden';
        } else {
            overlay.classList.remove('open');
            setTimeout(() => overlay.style.display = 'none', 300);
            document.body.style.overflow = '';
        }
    }
}

function handleCepInput(event) {
    let value = event.target.value.replace(/\D/g, "");
    if (value.length > 5) value = value.substring(0, 5) + "-" + value.substring(5, 8);
    event.target.value = value;
    if (value.replace("-", "").length === 8) fetchAddress(value.replace("-", ""));
}

function fetchAddress(cep) {
    if (!cep) cep = document.getElementById('cep-input').value.replace("-", "");
    if (cep.length !== 8) return;
    const addressSpan = document.getElementById('cep-address');
    addressSpan.innerText = "Buscando endereço...";
    fetch(`https://viacep.com.br/ws/${cep}/json/`)
        .then(r => r.json())
        .then(data => {
            if (data.erro) {
                addressSpan.innerText = "CEP não encontrado.";
                addressSpan.style.color = "#e10600";
            } else {
                addressSpan.innerText = `${data.logradouro}, ${data.bairro} - ${data.localidade}/${data.uf}`;
                addressSpan.style.color = "#00C000";
                localStorage.setItem('userCep', cep);
                localStorage.setItem('userAddress', addressSpan.innerText);
            }
        }).catch(() => {
            addressSpan.innerText = "Erro ao buscar endereço.";
            addressSpan.style.color = "#e10600";
        });
}

// Lógica de Filtragem em Dois Níveis
let currentCategory = 'all';
let currentTeam = 'all';

const TEAMS_DATA = {
    ferrari: { name: 'FERRARI', icon: 'images/teams/ferrari.png' },
    redbull: { name: 'RED BULL', icon: 'images/teams/redbull.png' },
    mercedes: { name: 'MERCEDES', icon: 'images/teams/mercedes.jpg' },
    mclaren: { name: 'McLAREN', icon: 'images/teams/mclaren.png' },
    astonmartin: { name: 'ASTON MARTIN', icon: 'images/teams/astonmartin.svg' },
    alpine: { name: 'ALPINE', icon: 'images/teams/alpine.png' },
    sauber: { name: 'SAUBER', icon: 'images/teams/sauber.jpg' },
    williams: { name: 'WILLIAMS', icon: 'images/teams/williams.webp' },
    haas: { name: 'HAAS', icon: 'images/teams/haas.webp' },
    vcarb: { name: 'VISA CASH APP RB', icon: 'images/teams/vcarb.jpg' },
    apxgp: { name: 'APXGP', icon: 'images/teams/apxgp.svg' },
    f1academy: { name: 'F1 ACADEMY', icon: 'images/teams/f1academy.svg' },
    audi: { name: 'AUDI', icon: 'images/teams/audi.svg' },
    all: { name: 'TODAS', icon: 'images/teams/f1.png' }
};

document.addEventListener('DOMContentLoaded', () => {
    const categoryFilter = document.getElementById('category-filter');
    const teamFilterContainer = document.getElementById('team-filter-container');
    const teamFilterBar = document.getElementById('team-filter');

    // Inicialização do CEP
    const savedCep = localStorage.getItem('userCep');
    const savedAddress = localStorage.getItem('userAddress');
    if (savedCep && document.getElementById('cep-input')) {
        document.getElementById('cep-input').value = savedCep.substring(0, 5) + "-" + savedCep.substring(5, 8);
        document.getElementById('cep-address').innerText = savedAddress;
    }

    // Evento de clique nas Categorias
    categoryFilter.addEventListener('click', (e) => {
        const item = e.target.closest('.filter-item');
        if (!item) return;

        document.querySelectorAll('#category-filter .filter-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        currentCategory = item.dataset.category;
        currentTeam = 'all'; // Reset equipe ao mudar categoria

        updateTeamFilter();
        applyFilters();
    });

    // Evento de clique nas Equipes
    teamFilterBar.addEventListener('click', (e) => {
        const item = e.target.closest('.filter-item');
        if (!item) return;

        document.querySelectorAll('#team-filter .filter-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        currentTeam = item.dataset.team;
        applyFilters();
    });

    function updateTeamFilter() {
        if (currentCategory === 'all') {
            teamFilterContainer.style.display = 'none';
            return;
        }

        // Encontrar equipes disponíveis nesta categoria
        const availableTeams = new Set(['all']);
        document.querySelectorAll(`.product-card[data-category="${currentCategory}"]`).forEach(card => {
            if (card.dataset.team && card.dataset.team !== 'all') {
                availableTeams.add(card.dataset.team);
            }
        });

        if (availableTeams.size <= 1) {
            teamFilterContainer.style.display = 'none';
            return;
        }

        // Renderizar sub-filtros de equipes
        teamFilterContainer.style.display = 'block';
        teamFilterBar.innerHTML = '';
        
        availableTeams.forEach(teamId => {
            const team = TEAMS_DATA[teamId] || { name: teamId.toUpperCase(), icon: 'images/favicon.png' };
            const activeClass = teamId === 'all' ? 'active' : '';
            teamFilterBar.innerHTML += `
                <div class="filter-item ${activeClass}" data-team="${teamId}">
                    <img alt="${team.name}" src="${team.icon}" style="width: 40px; height: 40px; object-fit: contain;"/>
                    <span>${team.name}</span>
                </div>
            `;
        });
    }

    function applyFilters() {
        const heroSection = document.querySelector('.hero-product-container');
        const cards = document.querySelectorAll('.product-card');
        let visibleCount = 0;

        heroSection.style.display = (currentCategory === 'all') ? 'block' : 'none';

        cards.forEach(card => {
            const catMatch = (currentCategory === 'all' || card.dataset.category === currentCategory);
            const teamMatch = (currentTeam === 'all' || card.dataset.team === currentTeam);

            if (catMatch && teamMatch) {
                card.style.display = 'block';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });

        const counter = document.getElementById('products-count');
        if (counter) {
            counter.textContent = `Exibindo ${visibleCount} ${visibleCount === 1 ? 'produto' : 'produtos'}`;
        }
        
        renderSectionBanner(currentCategory);
    }

    // Inicialização
    applyFilters();
});

// Banner Dinâmico
const SECTION_BANNERS = {
    all: { cls:'sb-todos', title:'BLACK NOVEMBER: ACELERE SUA COLEÇÃO', sub:'92% OFF em brinquedos LEGO® F1® por tempo limitado.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a15 15 0 0 1 0 20"/><path d="M12 2a15 15 0 0 0 0 20"/><path d="M2 12h20"/></svg>' },
    'speed champions': { cls:'sb-craques', title:'LINHA SPEED CHAMPIONS', sub:'Réplicas autênticas dos carros de F1® mais rápidos do mundo.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>' },
    technic: { cls:'sb-lendas', title:'ENGENHARIA LEGO® TECHNIC™', sub:'Sinta o desafio de construir sistemas complexos e realistas.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>' },
    icons: { cls:'sb-colecionaveis', title:'LEGO® ICONS - LENDAS', sub:'Carros históricos e pilotos que mudaram o esporte para sempre.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><polyline points="8.21 13.89 7 22 12 18 17 22 15.79 13.88"/></svg>' },
    editions: { cls:'sb-selecoes', title:'LEGO® EDITIONS - CAPACETES', sub:'Exiba sua paixão com os capacetes icônicos dos seus pilotos favoritos.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/></svg>' },
    city: { cls:'sb-craques', title:'LEGO® CITY - F1® NO DIA A DIA', sub:'Leve a emoção da Fórmula 1® para as ruas da sua cidade LEGO®.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>' },
    duplo: { cls:'sb-todos', title:'LEGO® DUPLO® - PRIMEIRAS PISTAS', sub:'Diversão garantida para os pequenos pilotos começarem sua jornada.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>' },
    collectibles: { cls:'sb-colecionaveis', title:'COLECIONÁVEIS FÓRMULA 1®', sub:'Itens exclusivos e raros para os verdadeiros fãs de automobilismo.',
        icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v8"/><path d="M8 12h8"/></svg>' }
};

function renderSectionBanner(category) {
    const el = document.getElementById('section-banner');
    if (!el) return;
    const data = SECTION_BANNERS[category] || SECTION_BANNERS.all;
    el.className = 'section-banner show ' + data.cls;
    document.getElementById('sb-icon').innerHTML = data.icon;
    document.getElementById('sb-title').textContent = data.title;
    document.getElementById('sb-sub').textContent = data.sub;
}

// Favoritos (Wishlist) - Mantendo lógica existente
function toggleWishlist(event, element) {
    event.stopPropagation();
    const card = element.closest('.product-card');
    if (!card) return;
    const oc = card.getAttribute('onclick') || '';
    const m = oc.match(/'([^']+)\/index\.html/);
    if (!m) return;
    const slug = m[1].split('/').pop();
    const active = element.classList.toggle('active');
    if (window.LegoWishlist) {
        if (active) window.LegoWishlist.add(slug);
        else window.LegoWishlist.remove(slug);
    }
}

// Menu Lateral LEGO
function legoMenuGoTodos(e) {
    e.preventDefault();
    document.querySelector('#category-filter .filter-item[data-category="all"]')?.click();
    toggleSidebar();
    document.querySelector('.products-grid')?.scrollIntoView({behavior:'smooth'});
}

function legoMenuOpenCart(e) {
    e.preventDefault();
    toggleSidebar();
    if (window.LegoCart) window.LegoCart.open();
}

function legoMenuToggleGroup(btn) {
    const group = btn.closest('.lego-menu-group');
    group?.classList.toggle('open');
}
