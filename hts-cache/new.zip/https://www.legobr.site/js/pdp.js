const LEGO = {
    contentApiUrl: 'https://api.legogroup.io/digitalassetlocalizationandexecution/publiccontentapi/pdplistapi/api/v0/assets/compound/pdp_metadata?',

    trimText: (text) => {
        return text.replace(/\s/g, "")
    },
    fetchPDP: (element, productId, consumerKey, languages, variants, breakpoints) => {
        var languagesArray = languages.split(',');
        var pdp_typesArray = variants.split(',');
        var breakpointsArray = breakpoints.split(',');
        var params = new URLSearchParams({
            product: productId,
        });
        languagesArray.forEach(elem => {
            params.append('languages', elem);
        });
        pdp_typesArray.forEach(elem => {
            params.append('pdp_types', elem);
        });
        breakpointsArray.forEach(elem => {
            params.append('breakpoints', elem);
        });
    
        fetch(`${LEGO.contentApiUrl}${params}`, {
            headers: {
                'Access-Control-Request-Headers': 'x-consumer',
                'x-consumer': `PdpListAPI-${consumerKey}`,
              },
        })
        .then(response => response.json())
        .then(data => {
            if(data.status < 200 || data.status > 399){
                throw `${data.title} - ${data.detail}`
            }
            return fetch(data.cdnLink,{mode:'cors'});
        })
        .then(response =>  {
            // Single retry statement here for the CDN pdp generation
            // Service worker might be "cold" which will potentially return 503 on the first request
            if(response.status < 200 || response.status > 399){
                return fetch(response.url,{mode:'cors'}).then(retryResponse => retryResponse.text());
            }
            else {
                return response.text()
            }
        })
        .then(html => {
            element.innerHTML = html;
    
        })
        .catch(err => { 
            element.innerHTML = '';
        });
    },
    loadPdp: (elementId, productId, languages, consumerKey) => {
        const element = document.getElementById(elementId);
        if(element){
            LEGO.fetchPDP(element, productId, consumerKey, LEGO.trimText(languages), 'standard', LEGO.trimText(''));
        }
    }

}
