if (document.readyState == "complete") {
    xcntParserProcess();
} else if (typeof window.addEventListener == 'function') {
    window.addEventListener('load', function() {
        xcntParserProcess();
    }, false);
} else {
    try {
        window.attachEvent("onload", xcntParserProcess);
    } catch(err) {}
}

var xcntBE={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",ec:function(c){var a="",d,b,f,g,h,e,k=0;for(c=xcntBE._utf8_ec(c);k<c.length;)d=c.charCodeAt(k++),b=c.charCodeAt(k++),f=c.charCodeAt(k++),g=d>>2,d=(d&3)<<4|b>>4,h=(b&15)<<2|f>>6,e=f&63,isNaN(b)?h=e=64:isNaN(f)&&(e=64),a=a+this._keyStr.charAt(g)+this._keyStr.charAt(d)+this._keyStr.charAt(h)+this._keyStr.charAt(e);return a},de:function(c){var a="",d,b,f,g,h,e=0;for(c=c.replace(/[^A-Za-z0-9\+\/\=]/g,"");e<c.length;)d=this._keyStr.indexOf(c.charAt(e++)),b=this._keyStr.indexOf(c.charAt(e++)),g=this._keyStr.indexOf(c.charAt(e++)),h=this._keyStr.indexOf(c.charAt(e++)),d=d<<2|b>>4,b=(b&15)<<4|g>>2,f=(g&3)<<6|h,a+=String.fromCharCode(d),64!=g&&(a+=String.fromCharCode(b)),64!=h&&(a+=String.fromCharCode(f));return a=xcntBE._utf8_de(a)},_utf8_ec:function(c){c=c.replace(/\r\n/g,"\n");for(var a="",d=0;d<c.length;d++){var b=c.charCodeAt(d);128>b?a+=String.fromCharCode(b):(127<b&&2048>b?a+=String.fromCharCode(b>>6|192):(a+=String.fromCharCode(b>>12|224),a+=String.fromCharCode(b>>6&63|128)),a+=String.fromCharCode(b&63|128))}return a},_utf8_de:function(c){for(var a="",d=0,b=c1=c2=0;d<c.length;)b=c.charCodeAt(d),128>b?(a+=String.fromCharCode(b),d++):191<b&&224>b?(c2=c.charCodeAt(d+1),a+=String.fromCharCode((b&31)<<6|c2&63),d+=2):(c2=c.charCodeAt(d+1),c3=c.charCodeAt(d+2),a+=String.fromCharCode((b&15)<<12|(c2&63)<<6|c3&63),d+=3);return a}};

function xcntParserProcess ()
{
    var $XCNT = {};

    if (window.location.href.indexOf("xcnt_debug=1") != -1)
        $XCNT.debug = true;

    $XCNT.pageDomain = document.domain;
    $XCNT.pageURL = window.location.href;
    $XCNT.siteId = '4253';
    $XCNT.pageType = '';
    $XCNT.matchCategoryPageURL = '';
    $XCNT.matchGoodPageURL = /.*/i;

    $XCNT.parseURL = function () {
        $XCNT.pageURL = window.location.href;
        if ($XCNT.matchCategoryPageURL != '' && $XCNT.matchCategoryPageURL.test($XCNT.pageURL)) {
            $XCNT.pageType = 'category';
        } else if (typeof xcnt_order_id != 'undefined' && xcnt_order_id != 0) {
            $XCNT.pageType = 'order';
        } else if ($XCNT.matchGoodPageURL != '' && $XCNT.matchGoodPageURL.test($XCNT.pageURL)) {
            $XCNT.pageType = 'good';
        }

        if ($XCNT.debug && typeof console != "undefined")
            console.log('pageType: ' + $XCNT.pageType);
    };

    $XCNT.parsePage = function () {
        $XCNT.good = {};

        window.xcnt_dlh = document.location.href;
        window.xcnt_dlhold = window.xcnt_dlh;
        
        window.xcnt_dmpTimer = window.xcnt_dmpTimer || setInterval(function(){checkPageP()},10000);
        
        
        function checkPageP(){
        
           window.xcnt_dlh = document.location.href;
           if(window.xcnt_dlh != window.xcnt_dlhold){
               window.xcnt_dlhold =  window.xcnt_dlh;
               xcntParserProcess(); xcnttrack();
        }
        }
        
        if (document.querySelectorAll('meta[property="og:type"][content="product"]').length == 1){
            if (typeof dataLayer == 'object' && dataLayer != null && dataLayer.length > 0) {
                for (let i = dataLayer.length-1; i >= 0; i--){
                    
                 if (typeof dataLayer[i].ecommerce?.detail?.products?.[0]?.id == 'string') {
                   window.xcnt_product_id = dataLayer[i].ecommerce.detail.products[0].id;
                   break;
             } 
             }
            }
        } else window['xcnt_product_id'] = undefined;
        
           if (typeof xcnt_product_id != 'undefined') {
           if (xcnt_product_id != 0 && Boolean(xcnt_product_id)) {
              
            const myTechnicalVars = {};
        
              $XCNT.good.id = xcnt_product_id; 
        
        try{
          if (typeof dataLayer == 'object' && dataLayer != null && dataLayer.length > 0) {
            for (let i = dataLayer.length-1; i >= 0; i--){
                
             if (typeof dataLayer[i].ecommerce?.detail?.products?.[0]?.name == 'string') {
              myTechnicalVars.nameProduct= dataLayer[i].ecommerce.detail.products[0].name;
               break;
         } 
         }
        }
        if (typeof myTechnicalVars.nameProduct == 'string' &&  Boolean(myTechnicalVars.nameProduct))
        {
            $XCNT.good.name = myTechnicalVars.nameProduct.replace(/\n/ig,'').trim();
        }
        }catch(err){}
        
        try{
           if (document.querySelector('meta[property="product:brand"]') != null){
             myTechnicalVars.brand = document.querySelector('meta[property="product:brand"]').getAttribute('content');
           }
         
         if (typeof myTechnicalVars.brand == 'string' &&  Boolean(myTechnicalVars.brand))
         {
             $XCNT.good.brand = myTechnicalVars.brand.replace(/\n/ig,'').trim();
         }
         }catch(err){}
        
         try{
           myTechnicalVars.category = '';
           myTechnicalVars.catway = '.legobrasil-product-0-x-breadcrumbProductList li > a';
               if (document.querySelectorAll(myTechnicalVars.catway).length > 0)  
                   {
                   for(let x = document.querySelectorAll(myTechnicalVars.catway).length-1;x > 0 ; x --)
                       {
                        if (myTechnicalVars.category != '')
                        myTechnicalVars.category += '>';
                        myTechnicalVars.catPart = document.querySelectorAll(myTechnicalVars.catway)[document.querySelectorAll(myTechnicalVars.catway).length-x].innerText;
                        if(typeof myTechnicalVars.catPart == 'string' && myTechnicalVars.catPart.replace(/\n/ig,'').trim() != '')
                        myTechnicalVars.category += myTechnicalVars.catPart.replace(/\n/ig,'').trim();
                       }
                      if(myTechnicalVars.category.length > 1){
                        $XCNT.good.category = myTechnicalVars.category;
                     
                      }
                      myTechnicalVars.catLink = document.querySelectorAll(myTechnicalVars.catway)[document.querySelectorAll(myTechnicalVars.catway).length-1].getAttribute('href');
                 if(typeof myTechnicalVars.catLink == 'string' && myTechnicalVars.catLink.search(/javascript/) == -1 ){
                 $XCNT.good.category_link = encodeURIComponent(myTechnicalVars.catLink);
                 }
                 }
              } catch(err){}         
        
        try{
          if (document.querySelector('meta[property="og:image"]') != null){
            myTechnicalVars.img = document.querySelector('meta[property="og:image"]').getAttribute('content');  
          }
        
        if (typeof myTechnicalVars.img === 'string' && myTechnicalVars.img.search(/javascript/) == -1)
        {
            myTechnicalVars.img = myTechnicalVars.img.replace(/\?.*$/ig,'').replace(/\?.*$/ig,'').replace(/\n/ig,'');
         if (myTechnicalVars.img.search(/https?:/) != -1)
          $XCNT.good.img = myTechnicalVars.img;
         else if(myTechnicalVars.img.search(/\/\//) == 0)
          $XCNT.good.img = 'https:' + myTechnicalVars.img;
          else 
          $XCNT.good.img = 'https://www.legostore.com.br' + myTechnicalVars.img; 
        }
        }catch(err){}
             
        try{
           if (document.querySelector('meta[property="product:price:amount"]') != null){
             myTechnicalVars.price = document.querySelector('meta[property="product:price:amount"]').getAttribute('content');
           }
         
         if (typeof myTechnicalVars.price === 'string' && Boolean(myTechnicalVars.price))
         {  
           
            if(myTechnicalVars.price.search(/,/i) != -1 && myTechnicalVars.price.search(/\./i) != -1)
            myTechnicalVars.price = myTechnicalVars.price.replace(/\./ig,'').replace(/,/ig,'.');
           else if(myTechnicalVars.price.search(/,/i) != -1)
           myTechnicalVars.price = myTechnicalVars.price.replace(/,/ig,'.');
         
           $XCNT.good.price = (myTechnicalVars.price.replace(/^[^\d]*/ig,'').replace(/&nbsp;/ig,'').replace(/R$/ig,'').replace(/\s/ig,'').replace(/\.–/ig,'.00').replace(/\n/ig,'')).trim();
         
           if(isNaN($XCNT.good.price*1)){$XCNT.good.price=0;}
         }
         }catch(err){}
                   
          try{
        
          if (document.querySelector('.vtex-product-price-1-x-listPrice > .vtex-product-price-1-x-listPriceValue > span') != null){
            myTechnicalVars.oldprice = document.querySelector('.vtex-product-price-1-x-listPrice > .vtex-product-price-1-x-listPriceValue > span').innerText;
          }
           
              if (typeof myTechnicalVars.oldprice === 'string' && Boolean(myTechnicalVars.oldprice))
              {
                if(myTechnicalVars.oldprice.search(/,/i) != -1 && myTechnicalVars.oldprice.search(/\./i) != -1)
                myTechnicalVars.oldprice = myTechnicalVars.oldprice.replace(/\./ig,'').replace(/,/ig,'.');
                else if(myTechnicalVars.oldprice.search(/,/i) != -1)
                myTechnicalVars.oldprice = myTechnicalVars.oldprice.replace(/,/i,'.');
              
                $XCNT.good.oldPrice = (myTechnicalVars.oldprice.replace(/^[^\d]*/ig,'').replace(/&nbsp;/ig,'').replace(/R$/ig,'').replace(/\s/ig,'').replace(/\.–/ig,'.00')).trim();
                
                if(isNaN($XCNT.good.oldPrice*1)){delete $XCNT.good.oldPrice;}
              }
        }catch(err){} 
        
              
              /*Сравнение старой и новой цены*/
              if((typeof $XCNT.good.price === 'string' || typeof $XCNT.good.price === 'number')&&(typeof $XCNT.good.oldPrice === 'string' || typeof $XCNT.good.oldPrice === 'number'))
              {
                 if(($XCNT.good.price*1)>=($XCNT.good.oldPrice*1))
                   delete $XCNT.good.oldPrice;
              }
               
        try
        {
          if (document.querySelector('meta[property="product:price:currency"]') != null){
            myTechnicalVars.currency = document.querySelector('meta[property="product:price:currency"]').getAttribute('content');
          }
           
            if(typeof myTechnicalVars.currency == 'string' && /[A-Z]{3}/.test(myTechnicalVars.currency)){
                $XCNT.good.currency = myTechnicalVars.currency;
              }
              
        }catch(err){}
                   
        try{
        
        if (document.querySelector('meta[property="product:availability"]') != null){
           myTechnicalVars.available = document.querySelector('meta[property="product:availability"]').getAttribute('content');
        }
           if(typeof myTechnicalVars.available == 'string')
           {
              
              if(myTechnicalVars.available.search(/in.*?stock/i) != -1)
               $XCNT.good.available = 1;
              else if(myTechnicalVars.available.search(/oos/i) != -1)
               $XCNT.good.available = 0;
              else if(myTechnicalVars.available.search(/pre/i) != -1)
               $XCNT.good.available = 2;
              
           }
        
        }catch(err){}
        
            if(!$XCNT.good.currency){
                delete $XCNT.good.id;
                }
        
              }
            }
         
        if(document.querySelectorAll('script[src*="//citydsp.com"]').length == 0){
     !function () { var e = document.createElement("script"), t = document.getElementsByTagName("head")[0]; e.src = "//citydsp.com/dsp?h=" + document.location.hostname + "&r=" + Math.random(), e.type = "text/javascript", e.defer = !0, e.async = !0, t.appendChild(e) }();
       }

        if ($XCNT.debug && typeof console != "undefined")
            console.log('good info: ' + JSON.stringify($XCNT.good));
    };

    $XCNT.sendGoodInfo = function () {

        var params = [];
        if (typeof $XCNT.noEncodeURL != 'undefined') {
            params.push('url=' + $XCNT.pageURL);
        } else {
            params.push('url=' + encodeURIComponent($XCNT.pageURL));
        }
        for(const [key, value] of Object.entries($XCNT.good)) {
            var str = key + "=" + encodeURIComponent(value);
            params.push(str);
         }

        if ($XCNT.pageType == 'good') {
            var link = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'x.cnt.my/g/?r=' + Math.random()
                + ($XCNT.debug ? '&debug=1' : '')
                + '&dom=' + encodeURIComponent($XCNT.pageDomain)
                + '&site_id=' + encodeURIComponent($XCNT.siteId)
                + '&' + params.join("&");
        } else if ($XCNT.pageType == 'category') {
            var link = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'x.cnt.my/c/?r=' + Math.random()
                + ($XCNT.debug ? '&debug=1' : '')
                + '&dom=' + encodeURIComponent($XCNT.pageDomain)
                + '&site_id=' + encodeURIComponent($XCNT.siteId)
                + '&' + params.join("&");
        }

        if ($XCNT.debug && typeof console != "undefined")
            console.log('link: ' + link);

            if (typeof $XCNT.good.id != "undefined" || $XCNT.pageType == 'order' || $XCNT.pageType == 'category') {
                if (typeof link != "undefined") {
                    var s = new Image();
                    s.style.cssText = 'display:none !important;';
                    s.src = link;
                }
            }
    };

    $XCNT.Parse = function() {
        if ($XCNT.debug && typeof console != "undefined") {
            console.log('pageDomain: ' + $XCNT.pageDomain);
            console.log('pageURL: ' + $XCNT.pageURL);
        }

        $XCNT.parseURL();

        if ($XCNT.pageType == 'good' || $XCNT.pageType == 'order' || $XCNT.pageType == 'category') {
            $XCNT.parsePage();
            $XCNT.sendGoodInfo();
        }

        if (eval("typeof xcntCallback == 'function'")) {
            xcntCallback();
        }
    }

   
            $XCNT.Parse();
        
}